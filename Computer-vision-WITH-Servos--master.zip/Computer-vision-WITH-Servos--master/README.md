# Computer-vision-WITH-Servos-
Always wanted a face tracker..Always. Now with the basics in these files, you can apply any sort of singling out/targeting/tracking system by switching up the cascaades 
From: https://sinistergenius.com/2016/12/27/open-cv/
